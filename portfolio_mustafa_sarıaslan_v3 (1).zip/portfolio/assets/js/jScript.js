// ════════════════════════════════════════
//  JSCRIPT.JS — Global JS
//  Mustafa Sarıaslan Portfolio
// ════════════════════════════════════════

// ─── THEME TOGGLE ───
const toggle = document.getElementById('theme-toggle');
const label  = document.getElementById('theme-label');

const savedTheme = localStorage.getItem('theme') || 'dark';
if (savedTheme === 'light') {
  document.body.classList.add('light');
  if (label) label.textContent = 'Açık Tema';
}

if (toggle) {
  toggle.addEventListener('click', () => {
    document.body.classList.toggle('light');
    const isLight = document.body.classList.contains('light');
    localStorage.setItem('theme', isLight ? 'light' : 'dark');
    if (label) label.textContent = isLight ? 'Açık Tema' : 'Koyu Tema';
  });
}

// ─── HAMBURGEr MENÜ ───
(function () {
  // Nav'a hamburger butonu + mobil menü DOM'unu ekle
  const nav = document.querySelector('nav');
  if (!nav) return;

  // Hamburger butonu oluştur
  const ham = document.createElement('button');
  ham.className = 'hamburger';
  ham.id = 'hamburger';
  ham.setAttribute('aria-label', 'Menüyü aç');
  ham.setAttribute('aria-expanded', 'false');
  ham.innerHTML = '<span></span><span></span><span></span>';
  nav.appendChild(ham);

  // Mobil menüyü oluştur
  const menu = document.createElement('div');
  menu.className = 'mobile-menu';
  menu.id = 'mobileMenu';
  menu.setAttribute('role', 'dialog');
  menu.setAttribute('aria-modal', 'true');

  // Navigasyon linklerini al
  const links = nav.querySelectorAll('.nav-links a');
  links.forEach(a => {
    const mob = document.createElement('a');
    mob.href = a.href;
    mob.className = 'mob-link';
    mob.textContent = a.textContent;
    if (a.style.color && a.style.color.includes('crimson') || a.getAttribute('style')?.includes('crimson')) {
      mob.classList.add('active');
    }
    mob.addEventListener('click', closeMenu);
    menu.appendChild(mob);
  });

  // Kapat butonu
  const closeBtn = document.createElement('button');
  closeBtn.className = 'mob-close';
  closeBtn.textContent = '✕ Kapat';
  closeBtn.addEventListener('click', closeMenu);
  menu.appendChild(closeBtn);

  document.body.appendChild(menu);

  function openMenu() {
    menu.style.display = 'flex';
    requestAnimationFrame(() => menu.classList.add('open'));
    ham.classList.add('active');
    ham.setAttribute('aria-expanded', 'true');
    document.body.style.overflow = 'hidden';
  }

  function closeMenu() {
    menu.classList.remove('open');
    ham.classList.remove('active');
    ham.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
    setTimeout(() => { menu.style.display = 'none'; }, 300);
  }

  ham.addEventListener('click', () => {
    menu.classList.contains('open') ? closeMenu() : openMenu();
  });

  // ESC ile kapat
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && menu.classList.contains('open')) closeMenu();
  });
})();

// ─── YUKARI ÇIK BUTONU ───
(function () {
  const btn = document.createElement('button');
  btn.className = 'scroll-top-btn';
  btn.id = 'scrollTopBtn';
  btn.innerHTML = '↑';
  btn.setAttribute('aria-label', 'Sayfanın başına git');
  document.body.appendChild(btn);

  window.addEventListener('scroll', () => {
    btn.classList.toggle('visible', window.scrollY > 400);
  }, { passive: true });

  btn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
})();

// ─── SAYAÇ ANİMASYONU ───
(function () {
  function animateCounter(el) {
    const target = parseInt(el.dataset.target, 10);
    if (isNaN(target)) return;
    const suffix = el.dataset.suffix || '';
    const duration = 1500;
    const step = 16;
    const steps = duration / step;
    const increment = target / steps;
    let current = 0;

    const timer = setInterval(() => {
      current += increment;
      if (current >= target) {
        current = target;
        clearInterval(timer);
      }
      el.textContent = Math.floor(current) + suffix;
    }, step);
  }

  const counterObserver = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting && !e.target.dataset.counted) {
        e.target.dataset.counted = 'true';
        animateCounter(e.target);
        counterObserver.unobserve(e.target);
      }
    });
  }, { threshold: 0.5 });

  document.querySelectorAll('.stat-num[data-target]').forEach(el => {
    counterObserver.observe(el);
  });
})();

// ─── SCROLL FADE ───
const fadeObserverGlobal = new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      e.target.classList.add('visible');
      fadeObserverGlobal.unobserve(e.target);
    }
  });
}, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

document.querySelectorAll('.fade-up').forEach((el, i) => {
  el.style.transitionDelay = `${(i % 5) * 80}ms`;
  fadeObserverGlobal.observe(el);
});
