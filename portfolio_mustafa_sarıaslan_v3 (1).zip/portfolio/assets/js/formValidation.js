// ════════════════════════════════════════
//  FORM VALIDATION — contact.html
//  Mustafa Sarıaslan Portfolio
// ════════════════════════════════════════

(function () {
  'use strict';

  // ─── ELEMENT REFERANSLARI ───
  const form         = document.getElementById('contactForm');
  const successPanel = document.getElementById('successPanel');
  const summaryBox   = document.getElementById('summaryBox');
  const resetBtn     = document.getElementById('resetBtn');
  const submitBtn    = document.getElementById('submitBtn');
  const spinner      = document.getElementById('spinner');
  const btnText      = document.getElementById('btnText');
  const btnIcon      = document.getElementById('btnIcon');
  const msgArea      = document.getElementById('message');
  const charCount    = document.getElementById('charCount');

  if (!form) return; // Sadece contact sayfasında çalış

  // ─── REGEX KALİPLARI ───
  const EMAIL_REGEX = /^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$/;
  const PHONE_REGEX = /^(\+90|0)(5\d{2})[- ]?(\d{3})[- ]?(\d{2})[- ]?(\d{2})$/;
  const NAME_REGEX  = /^[a-zA-ZğüşıöçĞÜŞİÖÇ\s'\-]{2,50}$/;

  // ─── YARDIMCI FONKSIYONLAR ───

  function getEl(id)      { return document.getElementById(id); }
  function getErr(id)     { return document.getElementById(id + 'Error'); }

  function showError(fieldId, message) {
    const input = getEl(fieldId);
    const err   = getErr(fieldId);
    if (!input || !err) return;

    input.classList.remove('success');
    input.classList.add('error');
    err.textContent = '⚠ ' + message;
    err.classList.add('show');
  }

  function showSuccess(fieldId) {
    const input = getEl(fieldId);
    const err   = getErr(fieldId);
    if (!input) return;

    input.classList.remove('error');
    input.classList.add('success');
    if (err) err.classList.remove('show');
  }

  function clearState(fieldId) {
    const input = getEl(fieldId);
    const err   = getErr(fieldId);
    if (input) { input.classList.remove('error', 'success'); }
    if (err)   { err.classList.remove('show'); }
  }

  // ─── DOĞRULAMA FONKSİYONLARI ───

  function validateFirstName() {
    const val = getEl('firstName').value.trim();
    if (!val) {
      showError('firstName', 'Ad alanı boş bırakılamaz.');
      return false;
    }
    if (val.length < 2) {
      showError('firstName', 'Ad en az 2 karakter olmalıdır.');
      return false;
    }
    if (!NAME_REGEX.test(val)) {
      showError('firstName', 'Ad yalnızca harf içerebilir.');
      return false;
    }
    showSuccess('firstName');
    return true;
  }

  function validateLastName() {
    const val = getEl('lastName').value.trim();
    if (!val) {
      showError('lastName', 'Soyad alanı boş bırakılamaz.');
      return false;
    }
    if (val.length < 2) {
      showError('lastName', 'Soyad en az 2 karakter olmalıdır.');
      return false;
    }
    if (!NAME_REGEX.test(val)) {
      showError('lastName', 'Soyad yalnızca harf içerebilir.');
      return false;
    }
    showSuccess('lastName');
    return true;
  }

  function validateEmail() {
    const val = getEl('email').value.trim();
    if (!val) {
      showError('email', 'E-posta alanı boş bırakılamaz.');
      return false;
    }
    if (!EMAIL_REGEX.test(val)) {
      showError('email', 'Geçerli bir e-posta adresi giriniz. (örn: ad@site.com)');
      return false;
    }
    showSuccess('email');
    return true;
  }

  function validatePhone() {
    const val = getEl('phone').value.trim();
    if (!val) {
      // İsteğe bağlı — boşsa OK
      clearState('phone');
      return true;
    }
    if (!PHONE_REGEX.test(val)) {
      showError('phone', 'Geçerli bir Türkiye telefon numarası giriniz. (örn: 05001234567)');
      return false;
    }
    showSuccess('phone');
    return true;
  }

  function validateSubject() {
    const val = getEl('subject').value;
    if (!val) {
      showError('subject', 'Lütfen bir konu seçiniz.');
      return false;
    }
    showSuccess('subject');
    return true;
  }

  function validateMessage() {
    const val = msgArea.value.trim();
    if (!val) {
      showError('message', 'Mesaj alanı boş bırakılamaz.');
      return false;
    }
    if (val.length < 20) {
      showError('message', `Mesaj en az 20 karakter olmalıdır. (Şu an: ${val.length})`);
      return false;
    }
    if (val.length > 1000) {
      showError('message', 'Mesaj 1000 karakteri geçemez.');
      return false;
    }
    showSuccess('message');
    return true;
  }

  function validateKvkk() {
    const cb = getEl('kvkk');
    const err = getErr('kvkk');
    if (!cb.checked) {
      cb.style.outline = '2px solid #e74c3c';
      if (err) err.classList.add('show');
      return false;
    }
    cb.style.outline = '2px solid #2ecc71';
    if (err) err.classList.remove('show');
    return true;
  }

  // ─── GERÇEK ZAMANLI (BLUR) DOĞRULAMA ───
  getEl('firstName').addEventListener('blur', validateFirstName);
  getEl('lastName') .addEventListener('blur', validateLastName);
  getEl('email')    .addEventListener('blur', validateEmail);
  getEl('phone')    .addEventListener('blur', validatePhone);
  getEl('subject')  .addEventListener('change', validateSubject);
  msgArea           .addEventListener('blur', validateMessage);
  getEl('kvkk')     .addEventListener('change', validateKvkk);

  // Yazarken hatayı temizle (daha iyi UX)
  ['firstName','lastName','email','phone'].forEach(id => {
    getEl(id).addEventListener('input', () => {
      const input = getEl(id);
      if (input.classList.contains('error') && input.value.trim()) {
        clearState(id);
      }
    });
  });

  // ─── KARAKTER SAYACI ───
  msgArea.addEventListener('input', () => {
    const len = msgArea.value.length;
    charCount.textContent = `${len} / 1000`;
    charCount.classList.remove('warn', 'over');
    if (len > 1000)      charCount.classList.add('over');
    else if (len > 800)  charCount.classList.add('warn');

    if (msgArea.classList.contains('error') && len >= 20) {
      clearState('message');
    }
  });

  // ─── FORM GÖNDERİM ───
  form.addEventListener('submit', function (e) {
    e.preventDefault();

    // Hepsini birden doğrula
    const results = [
      validateFirstName(),
      validateLastName(),
      validateEmail(),
      validatePhone(),
      validateSubject(),
      validateMessage(),
      validateKvkk(),
    ];

    const isValid = results.every(Boolean);

    if (!isValid) {
      // İlk hatalı alana scroll et
      const firstError = form.querySelector('.error, input[style*="outline: 2px solid rgb(231"]');
      if (firstError) firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }

    // ─── GÖNDERİM SİMÜLASYONU ───
    submitBtn.disabled = true;
    btnText.textContent = 'Gönderiliyor';
    btnIcon.style.display = 'none';
    spinner.style.display = 'block';

    // Gerçek projede: fetch('/api/contact', { method:'POST', body: formData })
    setTimeout(() => {
      const data = {
        firstName : getEl('firstName').value.trim(),
        lastName  : getEl('lastName').value.trim(),
        email     : getEl('email').value.trim(),
        phone     : getEl('phone').value.trim() || '—',
        subject   : getEl('subject').options[getEl('subject').selectedIndex].text,
        message   : msgArea.value.trim(),
      };

      // Özet kutusu
      summaryBox.innerHTML = `
        <strong>Gönderilen Bilgiler</strong><br><br>
        👤 <span>${data.firstName} ${data.lastName}</span><br>
        📧 <span>${data.email}</span><br>
        📞 <span>${data.phone}</span><br>
        📌 <span>${data.subject}</span><br>
        💬 <span>${data.message.substring(0, 80)}${data.message.length > 80 ? '…' : ''}</span>
      `;

      // Formu gizle, başarı panelini göster
      form.style.display = 'none';
      successPanel.classList.add('show');

      // Panele scroll
      successPanel.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 1800);
  });

  // ─── YENİ MESAJ (RESET) ───
  resetBtn.addEventListener('click', () => {
    form.reset();
    form.style.display = 'block';
    successPanel.classList.remove('show');
    submitBtn.disabled = false;
    btnText.textContent = 'Mesajı Gönder';
    btnIcon.style.display = 'inline';
    spinner.style.display = 'none';
    charCount.textContent = '0 / 1000';

    // Tüm field durumlarını temizle
    ['firstName','lastName','email','phone','subject','message'].forEach(clearState);
    const cb = getEl('kvkk');
    cb.style.outline = '';
    const kvkkErr = getErr('kvkk');
    if (kvkkErr) kvkkErr.classList.remove('show');

    form.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });

})();
