// ════════════════════════════════════════
//  PROJECTS.JS — Proje Listeleme + Favori + Sepet
//  JSON'dan veri oku → kartları render et → localStorage ile sakla
// ════════════════════════════════════════

let allProjects = [];
let activeFilter = 'Tümü';

// ══════════════════════════════════════
//  LOCALSTORAGE — Favoriler
// ══════════════════════════════════════

function getFavorites() {
  try { return JSON.parse(localStorage.getItem('ms_favorites')) || []; }
  catch { return []; }
}

function saveFavorites(favorites) {
  localStorage.setItem('ms_favorites', JSON.stringify(favorites));
}

function isFavorite(id) {
  return getFavorites().includes(id);
}

function toggleFavorite(id) {
  let favorites = getFavorites();
  const idx = favorites.indexOf(id);

  if (idx === -1) {
    favorites.push(id);
    showToast('❤️ Favorilere eklendi!');
  } else {
    favorites.splice(idx, 1);
    showToast('💔 Favorilerden çıkarıldı.');
  }

  saveFavorites(favorites);
  updateFavoriteButton(id);
  updateFavCounter();
  if (activeFilter === 'Favoriler') renderProjects('Favoriler');
}

function updateFavoriteButton(id) {
  const btn = document.querySelector(`.fav-btn[data-id="${id}"]`);
  if (!btn) return;
  const fav = isFavorite(id);
  btn.classList.toggle('active', fav);
  btn.setAttribute('aria-label', fav ? 'Favorilerden çıkar' : 'Favorilere ekle');
  btn.querySelector('.fav-icon').textContent = fav ? '❤️' : '🤍';
}

function updateFavCounter() {
  const count = getFavorites().length;
  const counter = document.getElementById('fav-count');
  if (counter) {
    counter.textContent = count;
    counter.style.display = count > 0 ? 'inline-flex' : 'none';
  }
  const favTab = document.querySelector('[data-filter="Favoriler"]');
  if (favTab) favTab.querySelector('.filter-num').textContent = count;
}

// ══════════════════════════════════════
//  LOCALSTORAGE — Sepet
// ══════════════════════════════════════

function getCart() {
  try { return JSON.parse(localStorage.getItem('ms_cart')) || []; }
  catch { return []; }
}

function saveCart(cart) {
  localStorage.setItem('ms_cart', JSON.stringify(cart));
}

function isInCart(id) {
  return getCart().includes(id);
}

function toggleCart(id) {
  let cart = getCart();
  const idx = cart.indexOf(id);

  if (idx === -1) {
    cart.push(id);
    showToast('🛒 Sepete eklendi!');
  } else {
    cart.splice(idx, 1);
    showToast('🗑️ Sepetten çıkarıldı.');
  }

  saveCart(cart);
  updateCartButton(id);
  updateCartCounter();
  renderCartPanel();
  if (activeFilter === 'Sepet') renderProjects('Sepet');
}

function updateCartButton(id) {
  const btn = document.querySelector(`.cart-btn[data-id="${id}"]`);
  if (!btn) return;
  const inCart = isInCart(id);
  btn.classList.toggle('active', inCart);
  btn.textContent = inCart ? '✓ Sepette' : '🛒 Sepete Ekle';
}

function updateCartCounter() {
  const count = getCart().length;
  const badge = document.getElementById('cart-badge');
  if (badge) {
    badge.textContent = count;
    badge.style.display = count > 0 ? 'inline-flex' : 'none';
  }
  const cartTab = document.querySelector('[data-filter="Sepet"]');
  if (cartTab) cartTab.querySelector('.filter-num').textContent = count;
}

// ══════════════════════════════════════
//  SEPET PANELİ
// ══════════════════════════════════════

function renderCartPanel() {
  const panel = document.getElementById('cart-panel');
  const list  = document.getElementById('cart-list');
  const total = document.getElementById('cart-total');
  if (!panel || !list) return;

  const cartIds = getCart();
  const cartItems = allProjects.filter(p => cartIds.includes(p.id));

  if (cartItems.length === 0) {
    list.innerHTML = `<p class="cart-empty">Sepetiniz boş 🛒</p>`;
    if (total) total.textContent = '₺0';
    return;
  }

  list.innerHTML = cartItems.map(p => `
    <div class="cart-item">
      <span class="cart-item-icon">${p.icon}</span>
      <div class="cart-item-info">
        <strong>${p.title}</strong>
        <small>${p.price > 0 ? '₺' + p.price : 'Ücretsiz'}</small>
      </div>
      <button class="cart-remove-btn" data-id="${p.id}" title="Sepetten çıkar">✕</button>
    </div>
  `).join('');

  const totalPrice = cartItems.reduce((sum, p) => sum + p.price, 0);
  if (total) total.textContent = totalPrice > 0 ? '₺' + totalPrice : 'Ücretsiz';

  list.querySelectorAll('.cart-remove-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = parseInt(btn.dataset.id);
      toggleCart(id);
    });
  });
}

function toggleCartPanel() {
  const panel = document.getElementById('cart-panel');
  if (!panel) return;
  const isOpen = panel.classList.toggle('open');
  renderCartPanel();
  document.body.style.overflow = isOpen ? 'hidden' : '';
}

// ══════════════════════════════════════
//  TOAST BİLDİRİMİ
// ══════════════════════════════════════

function showToast(message) {
  const existing = document.querySelector('.toast');
  if (existing) existing.remove();

  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.textContent = message;
  document.body.appendChild(toast);

  requestAnimationFrame(() => toast.classList.add('show'));
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 300);
  }, 2500);
}

// ══════════════════════════════════════
//  KART OLUŞTURMA
// ══════════════════════════════════════

function createProjectCard(project) {
  const fav    = isFavorite(project.id);
  const inCart = isInCart(project.id);

  const tagsHtml = project.tags
    .map(tag => `<span class="proj-tag">${tag}</span>`)
    .join('');

  const demoBtn = project.demo
    ? `<a href="${project.demo}" class="proj-btn proj-btn-primary" target="_blank">🚀 Demo</a>`
    : `<span class="proj-btn proj-btn-disabled">Demo Yok</span>`;

  const statusClass = project.status === 'Tamamlandı' ? 'status-done' : 'status-wip';

  const priceTag = project.price > 0
    ? `<span class="proj-price">₺${project.price}</span>`
    : `<span class="proj-price free">Ücretsiz</span>`;

  return `
    <div class="proj-card fade-up" data-id="${project.id}" style="--card-color: ${project.color}">
      <div class="proj-card-header">
        <div class="proj-icon" style="background: ${project.color}22; border-color: ${project.color}44;">
          ${project.icon}
        </div>
        <span class="proj-status ${statusClass}">${project.status}</span>
        <button
          class="fav-btn ${fav ? 'active' : ''}"
          data-id="${project.id}"
          aria-label="${fav ? 'Favorilerden çıkar' : 'Favorilere ekle'}"
          title="${fav ? 'Favorilerden çıkar' : 'Favorilere ekle'}"
        >
          <span class="fav-icon">${fav ? '❤️' : '🤍'}</span>
        </button>
      </div>

      <h3 class="proj-title">${project.title}</h3>
      <p class="proj-desc">${project.description}</p>

      <div class="proj-meta">
        <span class="proj-category">📁 ${project.category}</span>
        <span class="proj-year">📅 ${project.year}</span>
        ${priceTag}
      </div>

      <div class="proj-tags">${tagsHtml}</div>

      <div class="proj-actions">
        <a href="${project.github}" class="proj-btn proj-btn-outline" target="_blank">
          &lt;/&gt; Kod
        </a>
        ${demoBtn}
      </div>

      <button
        class="cart-btn ${inCart ? 'active' : ''}"
        data-id="${project.id}"
      >${inCart ? '✓ Sepette' : '🛒 Sepete Ekle'}</button>
    </div>
  `;
}

// ══════════════════════════════════════
//  RENDER (filtreye göre)
// ══════════════════════════════════════

function renderProjects(filter = 'Tümü') {
  const grid = document.getElementById('projects-grid');
  const emptyState = document.getElementById('empty-state');
  if (!grid) return;

  const favorites = getFavorites();
  const cartIds   = getCart();

  let filtered = allProjects;
  if (filter === 'Favoriler') {
    filtered = allProjects.filter(p => favorites.includes(p.id));
  } else if (filter === 'Sepet') {
    filtered = allProjects.filter(p => cartIds.includes(p.id));
  } else if (filter !== 'Tümü') {
    filtered = allProjects.filter(p => p.tags.includes(filter) || p.category === filter);
  }

  if (filtered.length === 0) {
    grid.innerHTML = '';
    if (emptyState) emptyState.style.display = 'flex';
    return;
  }

  if (emptyState) emptyState.style.display = 'none';
  grid.innerHTML = filtered.map(createProjectCard).join('');

  document.querySelectorAll('.proj-card.fade-up').forEach((el, i) => {
    el.style.transitionDelay = `${i * 80}ms`;
    fadeObserver.observe(el);
  });

  // Favori butonları
  grid.querySelectorAll('.fav-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      toggleFavorite(parseInt(btn.dataset.id));
    });
  });

  // Sepet butonları
  grid.querySelectorAll('.cart-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      toggleCart(parseInt(btn.dataset.id));
    });
  });
}

// ══════════════════════════════════════
//  FİLTRE ÇUBUĞU
// ══════════════════════════════════════

function buildFilters(projects) {
  const container = document.getElementById('filter-bar');
  if (!container) return;

  const favCount  = getFavorites().length;
  const cartCount = getCart().length;

  const allTags = ['Tümü', ...new Set(projects.flatMap(p => p.tags)), 'Favoriler', 'Sepet'];

  container.innerHTML = allTags.map(tag => {
    let count;
    if (tag === 'Tümü')      count = projects.length;
    else if (tag === 'Favoriler') count = favCount;
    else if (tag === 'Sepet')    count = cartCount;
    else count = projects.filter(p => p.tags.includes(tag)).length;

    const isActive = tag === activeFilter ? 'active' : '';
    const icon = tag === 'Favoriler' ? '❤️ ' : tag === 'Sepet' ? '🛒 ' : '';

    return `
      <button class="filter-btn ${isActive}" data-filter="${tag}">
        ${icon}${tag}
        <span class="filter-num">${count}</span>
      </button>
    `;
  }).join('');

  container.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      activeFilter = btn.dataset.filter;
      container.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      renderProjects(activeFilter);
    });
  });
}

// ══════════════════════════════════════
//  FADE OBSERVER
// ══════════════════════════════════════

const fadeObserver = new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      e.target.classList.add('visible');
      fadeObserver.unobserve(e.target);
    }
  });
}, { threshold: 0.1, rootMargin: '0px 0px -30px 0px' });

// ══════════════════════════════════════
//  SEPET PANELİ DOM OLUŞTURMA
// ══════════════════════════════════════

function createCartPanel() {
  if (document.getElementById('cart-panel')) return;

  const panel = document.createElement('div');
  panel.id = 'cart-panel';
  panel.className = 'cart-panel';
  panel.innerHTML = `
    <div class="cart-overlay" id="cart-overlay"></div>
    <div class="cart-drawer">
      <div class="cart-drawer-header">
        <h3>🛒 Seçilen Projeler</h3>
        <button class="cart-close-btn" id="cart-close">✕</button>
      </div>
      <div class="cart-list" id="cart-list"></div>
      <div class="cart-drawer-footer">
        <span>Toplam:</span>
        <strong id="cart-total">₺0</strong>
      </div>
    </div>
  `;
  document.body.appendChild(panel);

  document.getElementById('cart-close').addEventListener('click', toggleCartPanel);
  document.getElementById('cart-overlay').addEventListener('click', toggleCartPanel);
}

// ══════════════════════════════════════
//  SEPET BUTONU (floating)
// ══════════════════════════════════════

function createCartButton() {
  if (document.getElementById('floating-cart')) return;

  const btn = document.createElement('button');
  btn.id = 'floating-cart';
  btn.className = 'floating-cart-btn';
  btn.innerHTML = `🛒 <span id="cart-badge" class="cart-badge" style="display:none;">0</span>`;
  btn.title = 'Sepeti Aç';
  btn.addEventListener('click', toggleCartPanel);
  document.body.appendChild(btn);
}

// ══════════════════════════════════════
//  GÖMÜLÜ VERİ (fetch yerine — file:// uyumlu)
// ══════════════════════════════════════

const PROJECTS_DATA = [
  {
    "id": 1,
    "title": "Portfolio Web Sitesi",
    "description": "HTML, CSS ve JavaScript kullanılarak sıfırdan geliştirilmiş kişisel portföy sitesi. Karanlık/aydınlık tema, form doğrulama ve animasyonlar içerir.",
    "tags": ["HTML", "CSS", "JavaScript"],
    "icon": "🌐",
    "color": "#dc143c",
    "github": "#",
    "demo": "#",
    "status": "Tamamlandı",
    "category": "Web",
    "price": 0,
    "year": 2026
  },
  {
    "id": 2,
    "title": "Stok Takip Uygulaması",
    "description": "C# ve SQLite ile geliştirilen masaüstü tabanlı stok ve envanter takip sistemi. CRUD işlemleri ve raporlama özellikleri içerir.",
    "tags": ["C#", "SQLite", "Visual Studio"],
    "icon": "📦",
    "color": "#7c3aed",
    "github": "#",
    "demo": null,
    "status": "Tamamlandı",
    "category": "Masaüstü",
    "price": 299,
    "year": 2025
  },
  {
    "id": 3,
    "title": "Not Defteri (Java)",
    "description": "Java Swing ile geliştirilmiş basit ama işlevsel bir masaüstü not defteri uygulaması. Dosya kaydetme, açma ve düzenleme destekler.",
    "tags": ["Java", "Swing"],
    "icon": "📝",
    "color": "#0891b2",
    "github": "#",
    "demo": null,
    "status": "Tamamlandı",
    "category": "Masaüstü",
    "price": 0,
    "year": 2025
  },
  {
    "id": 4,
    "title": "İletişim Formu Doğrulama",
    "description": "Gerçek zamanlı alan doğrulama, karakter sayacı ve animasyonlu geri bildirim içeren gelişmiş bir JavaScript form doğrulama sistemi.",
    "tags": ["JavaScript", "HTML", "CSS"],
    "icon": "✅",
    "color": "#059669",
    "github": "#",
    "demo": "../pages/contact.html",
    "status": "Tamamlandı",
    "category": "Web",
    "price": 149,
    "year": 2026
  },
  {
    "id": 5,
    "title": "Donanım Tamir Asistanı",
    "description": "Bilgisayar donanımı arıza tespit ve tamir süreçlerini adım adım yönlendiren interaktif bir web tabanlı rehber uygulaması.",
    "tags": ["HTML", "CSS", "JavaScript"],
    "icon": "🔧",
    "color": "#d97706",
    "github": "#",
    "demo": "#",
    "status": "Geliştiriliyor",
    "category": "Web",
    "price": 199,
    "year": 2026
  },
  {
    "id": 6,
    "title": "Oyun İstatistik Takipçisi",
    "description": "Favori oyunlar için oynama süresi, başarım ve istatistikleri kaydeden localStorage tabanlı kişisel oyun kütüphanesi.",
    "tags": ["JavaScript", "LocalStorage", "CSS"],
    "icon": "🎮",
    "color": "#db2777",
    "github": "#",
    "demo": "#",
    "status": "Geliştiriliyor",
    "category": "Web",
    "price": 0,
    "year": 2026
  }
];

// ══════════════════════════════════════
//  INIT
// ══════════════════════════════════════

function init() {
  allProjects = PROJECTS_DATA;

  createCartPanel();
  createCartButton();
  buildFilters(allProjects);
  renderProjects('Tümü');
  updateFavCounter();
  updateCartCounter();
}

document.addEventListener('DOMContentLoaded', init);
